$(function() {
	var allpage, currentpage = 1,
		typeid = 'null',
		isenable = 'null',
		isdiscount = 'null';
	// 获取userInfo
	var userInfo = getuserInfo();
	if (userInfo) {
		$('.adminname').html('欢迎您 !  ' + userInfo.username);
	}
	//退出登录
	$('.logout').click(function() {
		logOut();
	})

	// add goods
	$('.addbtn').click(function() {
		window.location.href = "/freshManage/addgoods.html";
	})

	$PostApplication("goods/querygoodstype", {
		parentid: null
	}, function(res) {
		if (res.result.status == true) {
			let typelist = res.result.goodsTypeList;
			for (let i = 0; i < typelist.length; i++) {
				let str = '<option typeid=' + typelist[i].typeid + '>' + typelist[i].typename + '</option>';
				$('.g_type').append(str);
			}
		} else {
			alert(res.result.message);
		}
	})

	// 商品类型
	$('.g_type').change(function() {
		$('.gname').val('');
		typeid = $('.g_type option:checked').attr('typeid');
		currentpage = 1;
		console.log(currentpage, typeid, isenable, isdiscount)
		getList(currentpage, typeid, isenable, isdiscount);
	})
	// 商品状态
	$('.g_status').change(function() {
		$('.gname').val('');
		isenable = $(this).find("option:selected").attr("isenable");
		currentpage = 1;
		console.log(currentpage, typeid, isenable, isdiscount)
		getList(currentpage, typeid, isenable, isdiscount);
	})
	// 商品是否折扣
	$('.g_active').change(function() {
		$('.gname').val('');
		isdiscount = $('.g_active option:checked').attr('isdiscount');
		currentpage = 1;
		getList(currentpage, typeid, isenable, isdiscount);
	})

	// 表格翻页
	getList(currentpage, typeid, isenable, isdiscount);
	//上一页
	$("#up").click(function() {
		if (currentpage > 1) {
			currentpage--;
			$('.pagenum').html(currentpage);
			getList(currentpage, typeid, isenable, isdiscount);
		} else {
			alert("当前页已经是第一页！")
		}
	})
	//下一页
	$("#down").click(function() {
		console.log('down');
		if (currentpage < allpage) {
			currentpage++;
			$('.pagenum').html(currentpage);
			getList(currentpage, typeid, isenable, isdiscount);
		} else {
			alert("当前页已经是最后一页！")
		}
	})

	//获取商品信息列表
	function getList(pager, typeid, isenable, isdiscount) {
		let data = {
			pagesize: 8,
			pageno: pager
		};
		if (typeid != 'null') {
			data.typeid = typeid;
		}
		if (isenable != 'null') {
			data.isenable = isenable;
		}
		if (isdiscount != 'null') {
			data.isdiscount = isdiscount;
		}
		$ajaxPost('goods/getgoodsinfobypage/' + userInfo.id, data, function(res) {
			if (res.result.status == true) {
				allpage = res.result.page.totalPage;
				$('.allpage').html(allpage);
				$('.pagenum').html(pager);
				ceratList(res.result.page.goodList);
			} else {
				alert(res.result.message);
			}
		});
	}

	//动态生成商品列表
	function ceratList(list) {
		$('#tbcon').empty();
		for (var i = 0; i < list.length; i++) {
			let str = '<tr id=' + list[i].id + '><td>' + list[i].goodsname + '</td><td>' + list[i].goodstype.typename +
				'</td><td>' + list[i].nowPrice + '</td><td>' + list[i].oldPrice + '</td><td>' + list[i].stock + '</td><td>' +
				list[i].updateTime + '</td><td>' + (list[i].isenable == 1 ? '上架' : '下架') +
				'</td><td><button class="optionbtn update">修改</button><button class="optionbtn delete">删除</button></td></tr>';
			$('#tbcon').append(str);
		}
	}

	// 商品删除
	$("#tbcon").on('click', '.delete', function() {
		let ids = [],parentdom=$(this).parent().parent();
		ids.push(parentdom.attr('id'));
		$.ajax({
			type: "post",
			url: sysUrl + 'goods/deletedgoodsinfo/' + userInfo.id,
			crossDomain: true,
			contentType: "application/json",
			data: JSON.stringify(ids),
			xhrFields: {
				withCredentials: true
			},
			success:function(res){
				if (res.result.status == true) {
					parentdom.remove();
				} else {
					alert(res.result.message);
				}
			}
		})
	})
	
	// 商品修改
	$("#tbcon").on('click', '.update', function() {
		let id=parentdom=$(this).parent().parent().attr('id');
		window.location.href="/freshManage/addgoods.html?id="+id;
	})
	
	// 输入名称查找商品
	$('.searchgood').click(function(){
		var gname=$('.gname').val();
		$(".g_type").val("null");
		$(".g_status").val("null");
		$(".g_active").val("null");
		let data2={
			pageSize: 1000,
			pageNo: 1,
			keyWord:gname
		};
		$.ajax({
			type: "post",
			url: sysUrl + 'goods/searchpagegoods',
			crossDomain: true,
			contentType: "application/json",
			data: JSON.stringify(data2),
			xhrFields: {
				withCredentials: true
			},
			success:function(res){
				if (res.result.status == true) {
					allpage = res.result.page.totalPage;
					$('.allpage').html(allpage);
					$('.pagenum').html(1);
					ceratList(res.result.page.goodList);
				} else {
					alert(res.result.message);
				}
			}
		})
	})
	
})
