$(function() {
	var userInfo=getuserInfo(),h2s = $('.tab_hd h2'),
		tabindex = 0,userInfo = getuserInfo(),data={size:8};
	for (var i = 0; i < h2s.length; i++) {
		h2s[i].onclick = function() {
			tabindex = $(this).index();
			$(this).addClass('selected').siblings().removeClass('selected');
			if($(this).attr('data-typeid')!="null"){
				data.typeid=$(this).attr('data-typeid');
			}else{
				delete data.typeid;
			}
			getChart();
		}
	}
	

function getChart(){
	var xdata=[],sdata=[];
	$ajaxPost("goods/getsell/"+userInfo.id,data,function(res){
		if(res.result.status==true){
			var list=res.result.list;
			for(var i=0;i<list.length;i++){
				xdata.push(list[i].goodsname);
				sdata.push(list[i].sellCount);
				console.log(xdata)
				var myChart = echarts.init(document.getElementById('histogram'));
				var option = {
					title: {
						text: '销售量统计'
					},
					tooltip: {},
					legend: {
						data: ['销量']
					},
					xAxis: {
						data: xdata,
						show:true,
						name:"商品名称"
					},
					yAxis: {
						show:true,
						name:"销量(个)"
					},
					series: [{
						name: '销量',
						type: 'bar',
						data: sdata
					}],
					color: ['#fd8f4b'],
				};
				myChart.setOption(option);
			}
		}
	})
}
	getChart(0);

	if(userInfo){
		$('.adminname').html('欢迎您 !  '+userInfo.username);
	}
	//退出登录
	$('#logout').click(function(){
		logOut();
	})
	// 去收藏列表
	$('.tocollect').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/mycollect.html";
		}else{
			alert("请登录后再查看您的收藏！");
			window.location.href="/freshDirect/login.html";
		}
	})
	
})
