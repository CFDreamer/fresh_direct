$(function() {
	var status="null";
	// 获取userInfo
	var userInfo = getuserInfo();
	if (userInfo) {
		$('.adminname').html('欢迎您 !  ' + userInfo.username);
	}
	//退出登录
	$('.logout').click(function() {
		logOut();
	})
	
	$('.g_status').change(function() {
		status = $('.g_status option:selected').attr('status');
		getList();
	})

	//获取订单信息列表
	function getList() {
		let data={
			
		};
		if(status!='null'){
			data.state=status;
		}
		$.ajax({
				type: "post",
				url: sysUrl + "user/operation/getorder/" + userInfo.id,
				crossDomain: true,
				contentType: "application/json",
				data: JSON.stringify(data),
				xhrFields: {
					withCredentials: true
				},
				success: function(res) {
					if (res.result.status == true) {
						creatList(res.result.orderInfoList);
					} else {
						alert(res.result.message);
					}
				}
		})
	}
	getList();

	//动态生成列表
	function creatList(list) {
		$('#tbcon').empty();
		for (var i = 0; i < list.length; i++) {
			let str = '<tr id=' + list[i].id + '><td>' + list[i].ono + '</td><td>' +
				list[i].createTime +
				'</td><td>' + list[i].address.name + '</td><td>' + list[i].address.phone + '</td><td>'+(list[i].state == 0 ? '未完成' : '已完成') + '</td><td>' + list[i].allprice + '</td></tr>';
			$('#tbcon').append(str);
		}
	}

	// 启用或禁用
	$('#tbcon').on('click', '.disable', function(res) {
		var isenable = $(this).parent().parent().attr("isenable");
		var id = $(this).parent().parent().attr("id");
		isenable = isenable == 1 ? 0 : 1;
		let data = {
			id: id,
			isenable: isenable
		};
		$ajaxPost("user/update",data,function(res){
			if (res.result.status == true) {
				getList();
			} else {
				alert(res.result.message);
			}
		})
	})
	
})
