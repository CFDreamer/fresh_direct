$(function(){
	var userInfo=getuserInfo();
	if (userInfo) {
		$('.adminname').html('欢迎您 !  ' + userInfo.username);
	}
	$('.searchbtn').click(function(){
		var count=$('.countval').val();
		if(count<0){
			alert("请输入大于0的数字查询库存量！");
		}
		getList();
	})
	
	function getList(){
		var count=$('.countval').val(),data={},gname=$('.gname').val();
		if(count.trim().length!=0){
			data.size=count;
		}else{
			delete data.size;
		}
		if(gname.trim().length!=0){
			data.keyword=gname;
		}else{
			delete data.keyword;
		}
		$ajaxPost("goods/getstock/"+userInfo.id,data,function(res){
			if(res.result.status==true){
				var list=res.result.list;
				$("#tbcon").empty();
				for(var i=0;i<list.length;i++){
					let str = '<tr id=' + list[i].id + '><td>' + list[i].goodsname + '</td><td>' + list[i].goodstype.typename +
						'</td><td>' + list[i].nowPrice + '</td><td>' + list[i].sellCount + '</td><td>' + list[i].stock + '</td></tr>';
					$('#tbcon').append(str);
				}
			}
		}) 
	}
	getList();
	
	//退出登录
	$('.logout').click(function() {
		logOut();
	})
})