$(function() {
	var status="null";
	// 获取userInfo
	var userInfo = getuserInfo();
	if (userInfo) {
		$('.adminname').html('欢迎您 !  ' + userInfo.username);
	}
	//退出登录
	$('.logout').click(function() {
		logOut();
	})
	
	$('.g_status').change(function() {
		status = $('.g_status option:selected').attr('isenable');
		getList();
	})

	//获取商品信息列表
	function getList() {
		let data={};
		if(status!='null'){
			data.isenable=status;
		}
		$ajaxPost('user/getuserlist/' + userInfo.id, data, function(res) {
			if (res.result.status == true) {
				creatList(res.result.list);
			} else {
				alert(res.result.message);
			}
		});
	}
	getList();

	//动态生成商品列表
	function creatList(list) {
		$('#tbcon').empty();
		for (var i = 0; i < list.length; i++) {
			let str = '<tr id=' + list[i].id + ' isenable=' + list[i].isenable + '><td>' + list[i].username + '</td><td>' +
				list[i].sex +
				'</td><td>' + list[i].birthday + '</td><td>' + list[i].phone + '</td><td>' + list[i].signTime +
				'</td><td><button class="optionbtn disable">' + (list[i].isenable == 0 ? '启用' : '禁用') + '</button></td></tr>';
			$('#tbcon').append(str);
		}
	}

	// 启用或禁用
	$('#tbcon').on('click', '.disable', function(res) {
		var isenable = $(this).parent().parent().attr("isenable");
		var id = $(this).parent().parent().attr("id");
		isenable = isenable == 1 ? 0 : 1;
		let data = {
			id: id,
			isenable: isenable
		};
		$ajaxPost("user/update",data,function(res){
			if (res.result.status == true) {
				getList();
			} else {
				alert(res.result.message);
			}
		})
	})
	
})
