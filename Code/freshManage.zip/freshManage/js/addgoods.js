$(function(){
	var imgpath,goodsid,userInfo=getuserInfo(),url = window.location.search;
	
	// 判断是新增商品还是修改商品   
	if(url.indexOf("?") != -1) {    
		$("#pagetitle").html("修改商品");     
		goodsid = url.substr(url.indexOf("=") + 1);
		$ajaxGet("goods/getgoodsinfo/"+userInfo.id+'/'+goodsid,function(res){
			if(res.result.status==true){
				let goodsinfo=res.result.goodsInfo;
				$('input[name=gname]').attr('value',goodsinfo.goodsname);
				imgpath=goodsinfo.imagePath;
				$('#imgshow').attr('src',globalimg+imgpath);
				$(".gtype").find("option[typeid="+goodsinfo.goodstype.typeid+"]").attr("selected",true);
				$('input[name=goldprice]').val(goodsinfo.oldPrice);
				$('input[name=gnowprice]').val(goodsinfo.nowPrice);
				$('input[name=gcount]').val(goodsinfo.stock);
				$('input[name=gintroduce]').val(goodsinfo.introduce);
				$("input[name=gstatus][value="+goodsinfo.isenable+"]").prop("checked", "checked");
			}else{
				alert(res.result.message);
			}
		})
	}
	
	// img upload
    $('#filed').change(function(){
		var imgname=$('#filed')[0].files[0];
		var formData=new FormData();
		formData.append('image',imgname);
		
		$ajaxPostimg("upload//image/upload",formData,function(res){
			if(res.result.status==true){
				imgpath=res.imagepath;
				$('#imgshow').attr('src',globalimg+imgpath);
			}else{
				alert(res.result.message);
			}
		})
    })
	
	// 查询商品类型
	$PostApplication("goods/querygoodstype",{parentid:null},function(res){
		if(res.result.status==true){
			let typelist=res.result.goodsTypeList;
			for(let i=0;i<typelist.length;i++){
				let str='<option typeid='+typelist[i].typeid+'>'+typelist[i].typename+'</option>';
				$('.gtype').append(str);
			}
		}else{
			alert(res.result.message);
		}
	}),
	
	
	// 确认添加商品
	$("#confirmadd").click(function(){
		var gname=$('input[name=gname]').val();
		var gtypeid=$('.gtype option:selected').attr("typeid");
		var goldprice=$('input[name=goldprice]').val();
		var gnowprice=$('input[name=gnowprice]').val();
		var gcount=$('input[name=gcount]').val();
		var gintroduce=$('input[name=gintroduce]').val();
		var gstatus=$('input[name=gstatus]:checked').val();
		let data={
			goodsname:gname,
			imagepath:imgpath,
			typeid:gtypeid,
			oldprice:goldprice,
			nowprice:gnowprice,
			stock:gcount,
			introduce:gintroduce,
			isenable:gstatus
		};
		if(url.indexOf("?") == -1){
			$ajaxPost("goods/addgoodsinfo/"+userInfo.id,data,function(res){
				if(res.result.status==true){
					alert("商品新增成功！");
					window.location.href="/freshManage/index.html";
				}else{
					alert(res.result.message);
				}
			})
		}else{
			data.goodsid=goodsid;
			$ajaxPost("goods/updategoodsinfo/"+userInfo.id,data,function(res){
				if(res.result.status==true){
					alert("商品修改成功！");
					window.location.href="/freshManage/index.html";
				}else{
					alert(res.result.message);
				}
			})
		}
		
	})
	
})