const sysUrl="http://120.78.165.199:8080/freshdirect/";
const globalimg="http://120.78.165.199:8080/";

function $ajaxPost(url,data,success){
	$.ajax({
		type:"post",
		url:sysUrl+url,
		data:data,
		crossDomain: true,
		xhrFields: {
			withCredentials: true
		},
		success:success
	})
}

function $ajaxGet(url,success){
	$.ajax({
		type:"get",
		url:sysUrl+url,
		crossDomain: true,
		xhrFields: {
			withCredentials: true
		},
		success:success
	})
}

function $ajaxPostimg(url,data,success){
	$.ajax({
		type:"post",
		url:sysUrl+url,
		data:data,
		crossDomain: true,
		xhrFields: {
			withCredentials: true
		},
		contentType:false,
		cache:false,
		processData:false,
		success:success
	})
}
function $PostApplication(url,data,success){
	$.ajax({
		type:"post",
		url:sysUrl+url,
		crossDomain: true,
		contentType:"application/json",
		data:JSON.stringify(data),
		xhrFields: {
			withCredentials: true
		},
		success:success
	})
}

//存储userInfo
function setuserInfo(userInfo){
	localStorage.setItem('userInfo1',JSON.stringify(userInfo));
}
function getuserInfo(){
	return JSON.parse(localStorage.getItem('userInfo1'));
}

// 退出登录
function logOut(){
	$ajaxGet("user/logout",function(res){
		if(res.result.status==true){
			localStorage.removeItem('userInfo1');
			window.location.href="/freshManage/login.html";
		}else{
			alert(res.result.message);
		}
	})
}			



