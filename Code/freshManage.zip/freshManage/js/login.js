$(function(){
	$('#adminLogin').click(function(){
		var loginname=$('input[name=username]').val();
		var password=$('input[name=password]').val();
		let data={
			loginname:loginname,
			password:password,
			logintype:0,
			usagetype:1
		};
		$ajaxPost("user/login",data,function(res){
			if(res.result.status==true){
				setuserInfo(res.result.userInfo);
				alert("登录成功！")
				window.location.href="/freshManage/index.html";
			}
			else{
				alert(res.result.message);
			}
		})
	});
})