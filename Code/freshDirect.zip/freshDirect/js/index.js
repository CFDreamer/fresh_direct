$(function(){
	// 获取userInfo
	let userInfo=getuserInfo();
	if(userInfo){
		$('.username').html('欢迎您 !  '+userInfo.username);
	}
	//退出登录
	$('#logout').click(function(){
		logOut();
		window.location.href="/freshDirect/index.html";
	})
	// 去收藏列表
	$('.tocollect').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/mycollect.html";
		}else{
			alert("请登录后再查看您的收藏！");
			window.location.href="/freshDirect/login.html";
		}
	})
	$('.shopcar').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/shopCar.html";
		}else{
			alert("请登录后再查看您的购物车！");
			return false;
		}
	})
	// 我的订单
	$('.myorder').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/order_details.html";
		}else{
			alert("请登录后再查看您的订单！");
			return false;
		}
	})
	
	
	
	// 获取三种类型的商品
	$ajaxGet("goods/getfirstpageinfo",function(res){
		if(res.result.status==true){
			hotlist(res.result.hotList);
			newlist(res.result.newList);
			discountlist(res.result.disCountList);
		}else{
			alert(res.result.message);
		}
	})
	
	// 去收藏列表
	$('.tocollect').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/mycollect.html";
		}else{
			window.location.href="/freshDirect/login.html";
		}
	})
	
	//热门商品
	function hotlist(list){
		for(var i=0;i<list.length;i++){
			let hotstr='<a href="goodsdetail.html?id='+list[i].id+'"><div class="hotpro" id='+list[i].id+'><img src="'+globalimg+list[i].imagePath+'"><div class="hotpro_rg rg"><div class="h4Title">'+list[i].goodsname+'</div>';
			hotstr+='<span>☆☆☆☆☆</span><i>价格:'+list[i].nowPrice+'元</i></div></div></a>';
			$('.hot_bd').append(hotstr);
		}
	}
	

	// 最新上架
	function newlist(list){
		for(var i=0;i<list.length;i++){
			if(i<18){
				let newstr='<a href="goodsdetail.html?id='+list[i].id+'"><div class="newpro"><img src="'+globalimg+list[i].imagePath+'"><div class="newinfo"><div class="h4Title"><span>商品名:</span>'+list[i].goodsname+'</div>';
				newstr+='<i>价格:'+list[i].nowPrice+'元</i></div></div></a>';
				$('.new').append(newstr);
			}
		}
	}

	// 打折商品
	function discountlist(list){
		for(var i=0;i<list.length;i++){
			if(i<18){
				let discountstr='<a href="goodsdetail.html?id='+list[i].id+'"><div class="newpro"><img src="'+globalimg+list[i].imagePath+'"><div class="newinfo"><div class="h4Title" id="discountname"><span>商品名:</span>'+list[i].goodsname+'</div>';
				discountstr+='<div class="h4Title"><span>分类:</span>'+list[i].goodstype.typename+'</div><i>现价:'+list[i].nowPrice+'元</i><em>原价:'+list[i].oldPrice+'元</em></div></div></a>';
				$('.discount').append(discountstr);
			}
		}
	}
	
	// 查询商品类型
	$PostApplication("goods/querygoodstype",{parentid:null},function(res){
		if(res.result.status==true){
			let typelist=res.result.goodsTypeList;
			for(let i=0;i<typelist.length;i++){
				let str='<li><a href="/freshDirect/searchgoods.html?keyword=null&typeid='+typelist[i].typeid+'&searchid=null">'+typelist[i].typename+'</a></li>';
				$('.typemenu').append(str);
			}
		}else{
			alert(res.result.message);
		}
	})

	
	// searchgoods
	$('.tosearch').click(function(res){
		let keyword=$('.searchinput').val();
		if(keyword.trim()==''){
			alert("请输入关键字进行查询");
			return false;
		}
		window.location.href="/freshDirect/searchgoods.html?keyword="+keyword+"&typeid=null&searchid=null";
	})

	
})