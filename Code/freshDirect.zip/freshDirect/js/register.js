$(function() {
	$('.auth').data({'s': 0});
	$('input[name=username]').blur(function(){
		username=this.value.replace(/\s+/g, "");
		if(username.length<2){
			$(this).data({'s':0});
			$(this).parent().next().show();
		}
		else{
			$(this).data({'s':1});
			$(this).parent().next().hide();
		}
	});
	$('input[name=password]').blur(function(){
		password=this.value.replace(/\s+/g, "");
		if(password.length<6){
			$(this).data({'s':0});
			$(this).parent().next().show();
		}
		else{
			$(this).data({'s':1});
			$(this).parent().next().hide();
		}
	});
	$('input[name=repassward]').blur(function(){
		repassward=this.value;
		if(repassward!=password){
			$(this).data({'s':0});
			$(this).parent().next().show();
		}
		else{
			$(this).data({'s':1});
			$(this).parent().next().hide();
		}
	});
	$('input[name=phone]').blur(function(){
		phone=this.value;
		if(!(/^1[34578]\d{9}$/).test(phone)){
			$(this).data({'s':0});
			$(this).parent().next().show();
		}
		else{
			$(this).data({'s':1});
			$(this).parent().next().hide();
		}
	});
	// 获取验证码
	$('.sendcode').click(function() {
		phone = $('form [name=phone]').val();
		if(phone==''){
			alert("请输入手机号获取验证码");
			return false;
		}
		settime(60,$('.sendcode'));
		$ajaxPost("sms/sendcode",{
			phonenumber:phone,
			captchatype:5002,
			flag:5002
		},function(res){
			if(res.result.status==true){
			}else{
				alert(res.result.message);
			}
		})
		
	});

	//点击注册发送请求
	$('#registerbtn').click(function() {
		sex=$('input[name=sex]:checked').val();
		birthday=$('input[name=birthday]').val();
		code=$('input[name=authcode]').val();
		// var form = new FormData(document.getElementById("registerForm"));
		let data={
				username:username,
				phone:phone,
				sex:sex,
				password:password,
				birthday:birthday,
				captcha:code
			};
		console.log(username,phone,sex,password,birthday,code);
		$ajaxPost("user/register",data,function(res){
			if(res.result.status==true){
				alert("注册成功，请登录！")
				window.location.href="login.html";
			}
			else{
				alert(res.result.message);
			}
		})
// 		$.ajax({
// 			type: "POST",
// 			url: "http://localhost:8080/freshdirect/user/register",
// 			data: {
// 				username:username,
// 				phone:phone,
// 				sex:sex,
// 				password:password,
// 				birthday:birthday,
// 				captcha:code
// 			},
// 			crossDomain: true,
// 			xhrFields: {
// 				withCredentials: true
// 			},
// 			success: function(res) {
// 				console.log(res);
// 			}
// 		});
	});
})
