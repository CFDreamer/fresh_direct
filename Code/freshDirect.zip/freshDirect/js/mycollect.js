$(function(){
	var userInfo=getuserInfo();
	// get collect list
	$ajaxGet("user/operation/getcollections/"+userInfo.id,function(res){
		if(res.result.status==true){
			collectlist(res.result.listUserCollections);
		}else{
			alert(res.result.message);
		}
	})
	
	function collectlist(list){
		for(var i=0;i<list.length;i++){
			let newstr='<a href="goodsdetail.html?id='+list[i].gid.id+'"><div class="newpro"><img src="'+globalimg+list[i].gid.imagePath+'"><div class="newinfo"><div class="h4Title"><span>商品名:</span>'+list[i].gid.goodsname+'</div><div class="h4Title"><span>库存量:</span>'+list[i].gid.stock+'个</div>';
			newstr+='<i>价格:'+list[i].gid.nowPrice+'元</i></div></div></a>';
			$('.new').append(newstr);
		}
	}
	
	if(userInfo){
		$('.username').html('欢迎您 !  '+userInfo.username);
	}
	//退出登录
	$('#logout').click(function(){
		logOut();
		window.location.href="/freshDirect/index.html";
	})
	// 去收藏列表
	$('.tocollect').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/mycollect.html";
		}else{
			alert("请登录后再查看您的收藏！");
			window.location.href="/freshDirect/login.html";
		}
	})
})