const sysUrl="http://120.78.165.199/freshdirect/";
const globalimg="http://120.78.165.199:8080/";


function $ajaxPost(url,data,success){
	$.ajax({
		type:"post",
		url:sysUrl+url,
		data:data,
		crossDomain: true,
		xhrFields: {
			withCredentials: true
		},
		success:success
	})
}

function $ajaxGet(url,success){
	$.ajax({
		type:"get",
		url:sysUrl+url,
		crossDomain: true,
		xhrFields: {
			withCredentials: true
		},
		success:success
	})
}
function $PostApplication(url,data,success){
	$.ajax({
		type:"post",
		url:sysUrl+url,
		crossDomain: true,
		contentType:"application/json",
		data:JSON.stringify(data),
		xhrFields: {
			withCredentials: true
		},
		success:success
	})
}

//存储userInfo
function setuserInfo(userInfo){
	console.log(userInfo)
	localStorage.setItem('userInfo',JSON.stringify(userInfo));
}
function getuserInfo(){
	return JSON.parse(localStorage.getItem('userInfo'));
}

// 退出登录
function logOut(){
	$ajaxGet("user/logout",function(res){
		if(res.result.status==true){
			localStorage.removeItem('userInfo');
			window.location.reload();
		}else{
			alert(res.result.message);
		}
	})
}
function settime(seconds, obj) {
	console.log(seconds)
	if (seconds > 1) {
		seconds--;
		$(obj).html(seconds + "s后可重新获取 ").attr("disabled", true).addClass('disablebtn'); //禁用按钮
		// 定时1秒调用一次
		setTimeout(function() {
			settime(seconds, obj);
		}, 1000);
	} else {
		$(obj).html("获取验证码").attr("disabled", false).removeClass('disablebtn'); //启用按钮
	}
}
