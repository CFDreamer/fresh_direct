$(function() {
	var userInfo = getuserInfo();
	getOrder(1);
	// status tab
	$('.nav-tabs li').click(function() {
		let orderstatus = $(this).find('a').attr('href');
		let status = orderstatus == '#unfinshed' ? 0 : 1;
		getOrder(status);
	})
	// show detail
	$('.orderbox').on('click', '.to_details', function() {
		var ono = $(this).parent().parent().attr('ono');
		$(".details").show();
		$('.mask').show();
		$('.tbody').html(""); //清空之前显示的商品详情
		$ajaxPost('user/operation/getorderdetail/' + userInfo.id + '/' + ono, {}, function(res) {
			if (res.result.status == true) {
				var list = res.result.orderDetailList;
				for (var i = 0; i < list.length; i++) {
					var tr = $('<tr></tr>');
					var goods_td = $('<td></td>');
					var price_td = $('<td></td>');
					var count_td = $('<td></td>');
					var subtotal_td = $('<td></td>');
					goods_td.addClass('goods').append("<img src=" + globalimg + list[i].gid.imagePath + ">").append("<span>" +
						list[i].gid.goodsname + "</span>");
					price_td.addClass('price').html(list[i].gid.nowPrice);
					count_td.addClass('count').append("<span>X " + list[i].count + "</span>");
					subtotal_td.addClass('subtotal').html("￥ " + (list[i].gid.nowPrice * list[i].count));
					tr.appendTo('.tbody').append(goods_td).append(price_td).append(count_td).append(subtotal_td);
				}
			} else {
				alert(res.result.message);
			}
		})
	})
	
	// delete
	$('.orderbox').on('click', '.deleteono', function(){
		var ono = $(this).parent().parent().attr('ono');
		var ostate = $(this).parent().parent().attr('ostate');
		$ajaxGet('user/operation/deleteorder/' + userInfo.id + '/' + ono, function(res) {
			if (res.result.status == true) {
				getOrder(ostate);
			} else {
				alert(res.result.message);
			}
		})
	})
	
	// to_pay
	$('.orderbox').on('click', '.to_pay', function(){
		var ono = $(this).parent().parent().attr('ono');
		var ostate = $(this).parent().parent().attr('ostate');
		$ajaxPost('user/operation/updateorderstate/' + userInfo.id + '/' + ono, function(res) {
			if (res.result.status == true) {
				getOrder(ostate);
			} else {
				alert(res.result.message);
			}
		})
	})
	
	// get order list
	function getOrder(status){
		let data = {
			state: status,
			uid: userInfo.id
		};
		$.ajax({
			type: "post",
			url: sysUrl + 'user/operation/getorder/' + userInfo.id,
			contentType: "application/json",
			data: JSON.stringify(data),
			crossDomain: true,
			xhrFields: {
				withCredentials: true
			},
			success: function(res) {
				if (res.result.status == true) {
					getorderList(res.result.orderInfoList);
				} else {
					alert(res.result.message);
				}
			}
		})
	}
	// list data
	function getorderList(orderList) {
		$('.orderbox').empty();
		for (var i = 0; i < orderList.length; i++) {
			var allorders = $('<div ono=' + orderList[i].ono + ' ostate=' + orderList[i].state + '></div>').addClass('allorders').appendTo($('.orderbox'));
			var ordernum = $('<div></div>').addClass('ordernum').html("订单编号：<span>" + orderList[i].ono + "</span>");
			var address = $('<div></div>').addClass('address');
			var address_hd = $('<div></div>').addClass('address_hd').append("<span class='name fl'>收货人：" + orderList[i].address
				.name + "</span>").append("<span class='tel rg'>联系方式：" + orderList[i].address.phone + "</span>");
			var address_bd = $('<div></div>').addClass('address_bd').html("收货地址：" + orderList[i].address.address);
			var note = $('<div></div>').addClass('note').append('<p>买家备注：</p>').append("<span>" + orderList[i].remarks +
				"</span>");
			address.append(address_hd).append(address_bd).append(note);
			var orderinfo = $('<div></div>').addClass('orderinfo').append("<span class='time'>订单时间：" + orderList[i].createTime +
				"</span>").append("<span class='allprice'>订单总价：" + orderList[i].allprice + "</span>").append(
				'<span class="to_pay '+'pay'+orderList[i].state+'">立即结算</span>').append(
				"<span class='to_details'>显示详情</span>").append("<div class='deleteono'><img src='images/delete.png'>删除</div>");
			var line = $('<div></div>').addClass('line');
			allorders.append(ordernum).append(address).append(line).append(orderinfo);
		}
	}

	$('.close').on('click', function() {
		$(".details").hide();
		$('.mask').hide();
	})
	
	if(userInfo){
		$('.username').html('欢迎您 !  '+userInfo.username);
	}
	//退出登录
	$('#logout').click(function(){
		logOut();
		window.location.href="/freshDirect/index.html";
	})
	// 去收藏列表
	$('.tocollect').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/mycollect.html";
		}else{
			alert("请登录后再查看您的收藏！");
			window.location.href="/freshDirect/login.html";
		}
	})

})
