$(function() {
	var goodsid, iscollect, userInfo = getuserInfo(),
		url = window.location.search;
	if (url.indexOf("?") != -1) {
		goodsid = url.substr(url.indexOf("=") + 1);

	}

	// get商品详情
	$ajaxGet("goods/getgoodsinfo/" + 1 + '/' + goodsid, function(res) {
		if (res.result.status == true) {
			getDetail(res.result.goodsInfo);
			getsimilarList(res.result.goodsInfo.goodstype.typeid);
		} else {
			alert(res.result.message);
		}
	})

	//判断是否收藏
	if (userInfo) {
		$ajaxGet("user/operation/iscollection/" + userInfo.id + '/' + goodsid, function(res) {
			if (res.status == true) {
				iscollect = res.flag;
				if (iscollect) {
					$('#tocollect span').css({
						'color': 'red'
					});
				}
			} else {
				// alert(res.result.message);
			}
		})
	}

	// 收藏
	$('#tocollect').click(function() {
		if (!userInfo) {
			alert("请先登录后再收藏商品！");
			return false;
		}
		if (iscollect) {
			// cancel collect
			$ajaxGet("user/operation/deletecollection/" + userInfo.id + '/' + goodsid, function(res) {
				if (res.result.status == true) {
					iscollect = false;
					$('#tocollect span').css({
						'color': '#999'
					});
				} else {
					alert(res.result.message);
				}
			})
		} else {
			// to collect
			$ajaxPost("user/operation/addcollection/" + userInfo.id + '/' + goodsid, {}, function(res) {
				if (res.result.status == true) {
					iscollect = true;
					$('#tocollect span').css({
						'color': 'red'
					});
				} else {
					alert(res.result.message);
				}
			})
		}
	})


	// 商品详情
	function getDetail(info) {
		$('.goodsimgpath').attr('src', globalimg + info.imagePath);
		$('.infotitle').html(info.goodsname);
		$('.infoprice').html(info.nowPrice+'元');
		$('.infostock').html('（还剩' + info.stock + '件）');
		$('.goodsintroduce').html(info.introduce);
	}

	// 相似商品的列表
	function getsimilarList(typeid) {
		$ajaxGet("goods/getsimilargoods/" + typeid, function(res) {
			if (res.result.status == true) {
				samelist(res.result.list);
			} else {
				alert(res.result.message);
			}
		})
	}

	// 渲染相似商品的列表
	function samelist(list) {
		for (var i = 0; i < list.length; i++) {
			let newstr = '<a href="goodsdetail.html?id=' + list[i].id + '"><div class="newpro"><img src="' + globalimg + list[
				i].imagePath + '"><div class="newinfo"><div class="h4Title"><span>商品名:</span>' + list[i].goodsname + '</div>';
			newstr += '<i>价格:' + list[i].nowPrice + '元</i></div></div></a>';
			$('.new').append(newstr);
		}
	}

	// 加入购物车
	$('.addcar').click(function() {
		if (!userInfo) {
			alert("请先登录后再收藏商品！");
			return false;
		}
		http://localhost:8080/freshdirect/user/operation/addshopcar/{userid}/{goodsid} POST
		$ajaxPost("user/operation/addshopcar/"+ userInfo.id + '/' + goodsid,{},function(res){
			if (res.result.status == true) {
				window.location.href="/freshDirect/shopCar.html";
			} else {
				alert(res.result.message);
			}
		})
	})
	
	if(userInfo){
		$('.username').html('欢迎您 !  '+userInfo.username);
	}
	//退出登录
	$('#logout').click(function(){
		logOut();
		window.location.href="/freshDirect/index.html";
	})
	// 去收藏列表
	$('.tocollect').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/mycollect.html";
		}else{
			alert("请登录后再查看您的收藏！");
			window.location.href="/freshDirect/login.html";
		}
	})
	// searchgoods
	$('.tosearch').click(function(res){
		let keyword=$('.searchinput').val();
		if(keyword.trim()==''){
			alert("请输入关键字进行查询");
			return false;
		}
		window.location.href="/freshDirect/searchgoods.html?keyword="+keyword+"&typeid=null&searchid=null";
	})
	$('.shopcar').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/shopCar.html";
		}else{
			alert("请登录后再查看您的购物车！");
			return false;
		}
	})

})
