$(function() {
	var userInfo = getuserInfo(),
		editid;
	//发送请求获取用户添加过的地址
	getAddresslist();

	//选择地址
	$('.addressList').on('click', '.address', function() {
		var addressId = $(this).attr('addressid');
		sessionStorage.setItem('addressId',addressId);
		document.location.href = "/freshDirect/orders.html";
	})
	//新增地址
	$('.to_address').on('click', function() {
		$('.proptitle').html('新增收货地址');
		$("#address_form").show();
		$('.mask').show();
	})
	$('#address_form .close').on('click', function() {
		$("#address_form").hide();
		$('.mask').hide();
	})
	// 编辑地址
	$('.addressList').on('click', '.edit', function() {
		var id = $(this).parent().attr('addressid');
		editid = id;
		$("#address_form").show();
		$('.mask').show();
		$('.proptitle').html('修改收货地址');
		editAddress(id);
		return false;
	})
	//删除地址
	$('.addressList').on('click', '.todelete', function() {
		event.stopPropagation();
		var id = $(this).parent().attr('addressid');
		var msg = confirm("您确定要删除吗？");
		if (msg) {
			$.ajax({
				type: "post",
				url: sysUrl + 'user/operation/updateuseraddress/' + userInfo.id,
				contentType: "application/json",
				data: JSON.stringify({
					address_id: id,
					isdeleted:1
				}),
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				success: function(res) {
					if (res.result.status == true) {
						getAddresslist();
					} else {
						alert(res.result.message);
					}
				}
			})
		}
		return false;
	})

	//选择地区省市区
	var address = $("#select_area option:selected").text();
	$("#select_area").change(function() {
		address = $("#select_area option:selected").text();
	})

	//新增地址表单验证
	$('.auth').data({
		's': 0
	});
	$('.form_bd input[name=receviename]').bind('focus', focusFn);
	$('.form_bd input[name=tel]').bind('focus', focusFn);
	$('.form_bd input[name=address]').bind('focus', focusFn);

	function focusFn() {
		this.value = "";
	}
	$('.form_bd input[name=receviename]').blur(function() {
		receviename = this.value.replace(/\s+/g, "");
		if (receviename.length < 2) {
			$(this).data({
				's': 0
			});
			$('.error').show().html('收货人姓名不能少于两位字符！');
		} else {
			$(this).data({
				's': 1
			});
			$('.error').hide();
		}
	});
	$('.form_bd input[name=tel]').blur(function() {
		tel = this.value;
		if (!/(^[1][359][0-9]{9})$/.test(tel)) {
			$(this).data({
				's': 0
			});
			$('.error').show().html('电话号码格式不正确！');
		} else {
			$(this).data({
				's': 1
			});
			$('.error').hide();
		}
	});
	$('.form_bd input[name=address]').blur(function() {
		address_detail = this.value;
		if (address_detail.length < 1) {
			$(this).data({
				's': 0
			});
			$('.error').show().html('请输入详细收货地址！');
		} else {
			$(this).data({
				's': 1
			});
			$('.error').hide();
		}
	});
	$('form [type=button]').click(function() {
		$('.auth').blur();
		tot = 0;
		$('.auth').each(function() {
			tot += $(this).data('s');
		})
		if (tot != 3) {
			return false;
		}
		address = address + address_detail;
		console.log(receviename + "*****" + tel + "*****" + "*****" + address);
		var isdefault = $('.form_bd input[name=defaultads]').prop('checked') == false ? 0 : 1;
		let data = {
			uid: userInfo.id,
			name: receviename,
			phone: tel,
			address: address,
			isdefault: isdefault
		};
		if ($('.proptitle').html() == '修改收货地址') {
			data.address_id = editid;
			$.ajax({
				type: "post",
				url: sysUrl + 'user/operation/updateuseraddress/' + userInfo.id,
				contentType: "application/json",
				data: JSON.stringify(data),
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				success: function(res) {
					if (res.result.status == true) {
						alert("恭喜您，修改成功");
						$('#address_form .close').click();
						getAddresslist();
					} else {
						alert(res.result.message);
					}
				}
			})
		}else{
			$.ajax({
				type: "post",
				url: sysUrl + 'user/operation/adduseraddress/' + userInfo.id,
				contentType: "application/json",
				data: JSON.stringify(data),
				crossDomain: true,
				xhrFields: {
					withCredentials: true
				},
				success: function(res) {
					if (res.result.status == true) {
						alert("恭喜您，新增成功");
						$('#address_form .close').click();
						getAddresslist();
					} else {
						alert(res.result.message);
					}
				}
			})
		}
		
	});

	function getAddresslist() {
		$.ajax({
			type: "post",
			url: sysUrl + 'user/operation/getuseraddress/' + userInfo.id,
			contentType: "application/json",
			data: JSON.stringify({
				uid: userInfo.id
			}),
			crossDomain: true,
			xhrFields: {
				withCredentials: true
			},
			success: function(res) {
				if (res.result.status == true) {
					if (res.result.userAddressList.length > 0) {
						let receiptAddressList = res.result.userAddressList;
						if (receiptAddressList.length == 0) {
							$('.noaddress').css({
								'display': 'block'
							});
							$('.default_address').css({
								'display': 'none'
							});
							return false;
						}
						$('.addressList').empty();
						for (var i = 0; i < receiptAddressList.length; i++) {
							if (receiptAddressList[i].isdefault == 1) {
								$('.default_address').html("默认地址");
							}
							var address = $('<div></div>').addClass('address').appendTo($('.addressList')).attr("addressid",
								receiptAddressList[i].address_id);
							var address_hd = $('<div></div>').addClass('address_hd').append("<span class='name fl'>" +
								receiptAddressList[i].name + "</span>").append("<span class='tel rg'>" + receiptAddressList[i].phone +
								"</span>");
							var address_bd = $('<div></div>').addClass('address_bd').html(receiptAddressList[i].address);
							var line = $('<div></div>').addClass('line');
							var delete_obj = $('<div></div>').addClass('delete todelete').append("<img src='images/delete.png'>").append("删除");
							var edit_obj = $('<div></div>').addClass('delete edit').append("<img src='images/delete.png'>").append("编辑");
							address.append(address_hd).append(address_bd).append(line).append(delete_obj).append(edit_obj);
						}
					} else {}
				} else {
					alert(res.result.message);
				}
			}
		})
	}

	function editAddress(address_id) {
		$.ajax({
			type: "post",
			url: sysUrl + 'user/operation/getuseraddress/' + userInfo.id,
			contentType: "application/json",
			data: JSON.stringify({
				address_id: address_id
			}),
			crossDomain: true,
			xhrFields: {
				withCredentials: true
			},
			success: function(res) {
				if (res.result.status == true) {
					let adsinfo = res.result.userAddressList[0];
					$('.form_bd input[name=receviename]').val(adsinfo.name);
					$('.form_bd input[name=tel]').val(adsinfo.phone);
				} else {
					alert(res.result.message);
				}
			}
		})
	}
	// 获取userInfo
	if(userInfo){
		$('.username').html('欢迎您 !  '+userInfo.username);
	}
	//退出登录
	$('#logout').click(function(){
		logOut();
		window.location.href="/freshDirect/index.html";
	})
	// 去收藏列表
	$('.tocollect').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/mycollect.html";
		}else{
			alert("请登录后再查看您的收藏！");
			window.location.href="/freshDirect/login.html";
		}
	})

})
