$(function(){
	$('#accountLogin').click(function(){
		var loginname=$('input[name=username]').val();
		var password=$('input[name=password]').val();
		let data={
			loginname:loginname,
			password:password,
			logintype:0,
			usagetype:0
		};
		$ajaxPost("user/login",data,function(res){
			if(res.result.status==true){
				setuserInfo(res.result.userInfo);
				alert("登录成功！")
				window.location.href="/freshDirect/index.html";
			}
			else{
				alert(res.result.message);
			}
		})
	});
	
	$('#sendcode').click(function() {
		var phone = $('input[name=phone]').val();
		if(phone.trim()==''){
			alert("请输入手机号");
			return false;
		}
		settime(60,$('#sendcode'));
		$ajaxPost("sms/sendcode",{
			phonenumber:phone,
			captchatype:5003
		},function(res){
			if(res.result.status==true){
				
			}else{
				alert(res.result.message);
			}
		})
	});
	
	$('#codeLogin').click(function(){
		var phonenumber=$('input[name=phone]').val();
		var captcha=$('input[name=captcha]').val();
		let data={
			phonenumber:phonenumber,
			captcha:captcha,
			logintype:1
		};
		$ajaxPost("user/login",data,function(res){
			if(res.result.status==true){
				setuserInfo(res.result.userInfo);
				alert("登录成功！")
				window.location.href="/freshDirect/index.html";
			}
			else{
				alert(res.result.message);
			}
		})
	});
})