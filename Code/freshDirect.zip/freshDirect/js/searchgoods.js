$(function(){
	let list=[],userInfo=getuserInfo(),url=window.location.href,pageNo=1,totalCount,totalPage,data={pageNo:pageNo,pageSize:20};
	function getQueryString(url) {
		if(url) {
			url=url.substr(url.indexOf("?")+1); //字符串截取，比我之前的split()方法效率高
		}
		var result = {}, //创建一个对象，用于存name，和value
		queryString =url || location.search.substring(1), //location.search设置或返回从问号 (?) 开始的 URL（查询部分）。
		re = /([^&=]+)=([^&]*)/g, //正则，具体不会用
		m;
		while (m = re.exec(queryString)) { //exec()正则表达式的匹配，具体不会用
			result[decodeURIComponent(m[1])] = decodeURIComponent(m[2]); //使用 decodeURIComponent() 对编码后的 URI 进行解码
		}
		return result;
	}
	var param=getQueryString(url);
	if(param.keyword!="null"){
		data.keyWord=param.keyword;
	}
	if(param.typeid!="null"){
		data.typeid=parseInt(param.typeid);
	}
	if(param.searchid!="null"){
		data.searchid=parseInt(param.searchid);
	}
	console.log(data)
	
	function getList(){
		$.ajax({
			type: "post",
			url: sysUrl + 'goods/searchpagegoods',
			crossDomain: true,
			contentType: "application/json",
			data: JSON.stringify(data),
			xhrFields: {
				withCredentials: true
			},
			success:function(res){
				if (res.result.status == true) {
					// var list=res.result.page.goodList;
					totalCount=res.result.page.totalCount;
					totalPage=res.result.page.totalPage;
					if(data.pageNo==1){
						list=res.result.page.goodList;
					}else{
						let rctlist=res.result.page.goodList;
						for(var i=0;i<rctlist.length;i++){
							list.push(rctlist[i]);
						}
					}
					$('.new').empty();
					for(var i=0;i<list.length;i++){
						let newstr='<a href="goodsdetail.html?id='+list[i].id+'"><div class="newpro"><img src="'+globalimg+list[i].imagePath+'"><div class="newinfo"><div class="h4Title"><span>商品名:</span>'+list[i].goodsname+'</div><div class="h4Title"><span>库存量:</span>'+list[i].stock+'个</div>';
						newstr+='<i>现价:'+list[i].nowPrice+'元</i></div></div></a>';
						$('.new').append(newstr);
					}
				} else {
					alert(res.result.message);
				}
			}
		})
	}
	getList();
	// searchgoods
	$('.tosearch').click(function(res){
		let keyword=$('.searchinput').val();
		if(keyword.trim()==''){
			alert("请输入关键字进行查询");
			return false;
		}
		data.keyWord=keyword;
		data.pageNo=1;
		$('.new').empty();
		getList();
	})
	
	$(window).bind("scroll", function (event) {
		var totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop()); //滚动条到网页头部的高度
		var textheight =$(document).height();//网页的高度
		if(totalheight==textheight){
			if(pageNo<totalPage){
				pageNo++;
				data.pageNo++;
				getList();
			}
		}
	})
	
	if(userInfo){
		$('.username').html('欢迎您 !  '+userInfo.username);
	}
	//退出登录
	$('#logout').click(function(){
		logOut();
		window.location.href="/freshDirect/index.html";
	})
	// 去收藏列表
	$('.tocollect').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/mycollect.html";
		}else{
			alert("请登录后再查看您的收藏！");
			window.location.href="/freshDirect/login.html";
		}
	})
	$('.shopcar').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/shopCar.html";
		}else{
			alert("请登录后再查看您的购物车！");
			return false;
		}
	})
	
	
})