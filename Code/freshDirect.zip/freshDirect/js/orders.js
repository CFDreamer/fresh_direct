$(function() {

var userInfo = getuserInfo(),
	// url = window.location.search,
	carids = JSON.parse(sessionStorage.getItem("shopcarIds")),
	addressid=sessionStorage.getItem("addressId");
	allprice = 0,
	ono='';
// if (url.indexOf("?") != -1) {
// 	let idparam = url.substr(url.indexOf("=") + 1).split(',');
// 	for (var i = 0; i < idparam.length; i++) {
// 		console.log(idparam[i])
// 		carids.push(parseInt(idparam[i]));
// 	}
// }
	getorderData();
	getAddress();
	//获取备注
	var bz="";
	$('.note input[type=text]').blur(function(){
		bz=this.value;
	})
	//点击确认付款按钮
	$('.pay').click(function(){
		if($('.detailads').html()==''){
			alert("请选择收货地址！");
			document.location.href="address.html";
			return false;
		}
		let data={
			carids:carids,
			allprice:allprice,
			remarks:bz,
			address_id:addressid
		}
		$.ajax({
			type: "post",
			url: sysUrl + 'user/operation/createorder/' + userInfo.id,
			contentType: "application/json",
			data: JSON.stringify(data),
			crossDomain: true,
			xhrFields: {
				withCredentials: true
			},
			success: function(res) {
				if (res.result.status == true) {
					$(".paybox").show();
					$('.mask').show();
					ono=res.result.orderInfo.ono;
				} else {
					alert(res.result.message);
				}
			}
		})
	})
	
	$('#confirmbtn').click(function(){
		$ajaxPost("user/operation/updateorderstate/"+userInfo.id+'/'+ono,{},function(res){
			if (res.result.status == true) {
				window.location.href="/freshDirect/order_details.html";
			} else {
				alert(res.result.message);
			}
		})
	})
	
	$('#cancelbtn').click(function(){
		$(".paybox").hide();
		$('.mask').hide();
		window.location.href="/freshDirect/order_details.html";
	})

function getorderData() {
	$.ajax({
		type: "post",
		url: sysUrl + 'user/operation/getaccountpage/' + userInfo.id,
		contentType: "application/json",
		data: JSON.stringify(carids),
		crossDomain: true,
		xhrFields: {
			withCredentials: true
		},
		success: function(res) {
			if (res.result.status == true) {
				getorderList(res.result.listUserShopCar);
			} else {
				alert(res.result.message);
			}
		}
	})
}

function getorderList(PurchaseList) {
	for (var i = 0; i < PurchaseList.length; i++) {
		var tr = $('<tr listid=' + PurchaseList[i].id + '></tr>');
		var goods_td = $('<td></td>');
		var price_td = $('<td></td>');
		var count_td = $('<td></td>');
		var subtotal_td = $('<td></td>');
		goods_td.addClass('goods').append("<img src=" + globalimg + PurchaseList[i].goodsInfo.imagePath + ">").append(
			"<span>" + PurchaseList[i].goodsInfo.goodsname + "</span>");
		price_td.addClass('price').html("￥ " + PurchaseList[i].goodsInfo.nowPrice);
		count_td.addClass('count').append("<span>X " + PurchaseList[i].count + "</span>");
		subtotal_td.addClass('subtotal').html("￥" + parseFloat(PurchaseList[i].goodsInfo.nowPrice * PurchaseList[i].count)
			.toFixed(2));
		tr.appendTo('.tbody').append(goods_td).append(price_td).append(count_td).append(subtotal_td);
		//计算总价
		allprice += parseInt(PurchaseList[i].goodsInfo.nowPrice * PurchaseList[i].count);
		$('.all_price').html("总金额：￥ " + allprice);
	}
}

function getAddress() {
	let data={};
	if(addressid){
		data={
			address_id:addressid
		}
	}else{
		data={
			isdefault: 1
		}
	}
	$.ajax({
		type: "post",
		url: sysUrl + 'user/operation/getuseraddress/' + userInfo.id,
		contentType: "application/json",
		data: JSON.stringify(data),
		crossDomain: true,
		xhrFields: {
			withCredentials: true
		},
		success: function(res) {
			if (res.result.status == true) {
				sessionStorage.removeItem('addressId');
				if (res.result.userAddressList.length > 0) {
					userAddressList=res.result.userAddressList;
					$('.addinfo em').html(userAddressList[0].address);
					$('.addinfo .name').html("姓名：" + userAddressList[0].name);
					$('.addinfo .tel').html("联系方式：" + userAddressList[0].phone);
					addressid=userAddressList[0].address_id;
				} else {
					$('.addinfo .name').css({
						'display': 'none'
					});
					$('.addinfo .tel').css({
						'display': 'none'
					});
					$('.addinfo em').html("暂无地址，点击右侧添加收货地址!");
				}
			}else{
				alert(res.result.message);
			}
		}
	})
}

	if(userInfo){
		$('.username').html('欢迎您 !  '+userInfo.username);
	}
	//退出登录
	$('#logout').click(function(){
		logOut();
		window.location.href="/freshDirect/index.html";
	})
	// 去收藏列表
	$('.tocollect').click(function(){
		if(userInfo){
			window.location.href="/freshDirect/mycollect.html";
		}else{
			alert("请登录后再查看您的收藏！");
			window.location.href="/freshDirect/login.html";
		}
	})
	// searchgoods
	$('.tosearch').click(function(res){
		let keyword=$('.searchinput').val();
		if(keyword.trim()==''){
			alert("请输入关键字进行查询");
			return false;
		}
		window.location.href="/freshDirect/searchgoods.html?keyword="+keyword+"&typeid=null&searchid=null";
	})


})